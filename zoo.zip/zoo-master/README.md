## ZOO

### Status
[![Build Status](https://travis-ci.com/LetayB/zoo.svg?branch=master)](https://travis-ci.com/LetayB/zoo)
[![Maintainability](https://api.codeclimate.com/v1/badges/d47ded4839fbfa524606/maintainability)](https://codeclimate.com/github/LetayB/zoo/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/d47ded4839fbfa524606/test_coverage)](https://codeclimate.com/github/LetayB/zoo/test_coverage)
[![Documentation Status](https://readthedocs.org/projects/zoodocs/badge/?version=latest)](https://zoodocs.readthedocs.io/en/latest/?badge=latest)