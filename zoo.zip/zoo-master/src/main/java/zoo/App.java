package zoo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import zoo.animal.Chat;
import zoo.animal.TypeAnimal;
import zoo.exception.AnimalDansMauvaisSecteurException;


public class App {

    private static final Logger logger = LogManager.getLogger(App.class);

    public static void main(String[] args) throws AnimalDansMauvaisSecteurException {

        logger.trace("Debut de l'application");
        logger.info("Nouvel animal : " + ani.getClass().toString());


        Zoo zoo = new Zoo();
      
		  zoo.ajouterSecteur(TypeAnimal.CHAT);
		  zoo.ajouterSecteur(TypeAnimal.CHIEN);
		  zoo.ajouterSecteur(TypeAnimal.CHAT);
	  	zoo.ajouterSecteur(TypeAnimal.CHIEN);
      zoo.ajouterSecteur(TypeAnimal.CHIEN);
      
      zoo.nouvelAnimal(new Chat("Felix"));
      zoo.nouvelAnimal(new Chat("Chaton"));
      zoo.nouvelAnimal(new Chat("Malot"));
      zoo.nouvelAnimal(new Chat("Griffe"));
      zoo.nouvelAnimal(new Chat("LeChat"));
      zoo.nouvelAnimal(new Chat("Truc"));

      System.out.println(zoo.nombreAnimaux());
	  }
}
