package zoo.exception;

public class LimiteVisiteurException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6809176605211516646L;

}
