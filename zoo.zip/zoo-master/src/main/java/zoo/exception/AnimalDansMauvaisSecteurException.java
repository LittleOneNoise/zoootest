package zoo.exception;

public class AnimalDansMauvaisSecteurException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6250957383005836673L;

}
