package zoo.animal;

public enum TypeAnimal {
	CHAT,
	CHIEN,
	LAPIN
}
