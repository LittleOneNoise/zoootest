package zoo.animal;

public class Chat extends Animal {

	public Chat(String name) {
		typeAnimal = TypeAnimal.CHAT;
		nomAnimal = name;
	}
}
