package zoo.animal;

public class Chien extends Animal {
	
	public Chien(String name) {
		typeAnimal = TypeAnimal.CHIEN;
		nomAnimal = name;
	}
}
