package zoo.animal;

public class Lapin extends Animal {

	public Lapin(String name) {
		typeAnimal = TypeAnimal.LAPIN;
		nomAnimal = name;
	}
}
